"use strict";

var canvas;
var gl;

var theta = 0.0;
var thetaLoc;
var angularVelocity = 0.1;
var direction = 1;

function initRotSquare() {
    canvas = document.getElementById("rot-canvas");
    gl = canvas.getContext("webgl2");
    if (!gl) {
        alert("WebGL isn't available");
    }

    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0);

    var program = initShaders(gl, "rot-v-shader", "rot-f-shader");
    gl.useProgram(program);

    var vertices = new Float32Array([
        0, 1, 0,
        -1, 0, 0,
        1, 0, 0,
        0, -1, 0
    ]);

    var bufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    thetaLoc = gl.getUniformLocation(program, "theta");
    var angularVelocityLoc = gl.getUniformLocation(program, "angularVelocity");
    gl.uniform1f(angularVelocityLoc, angularVelocity);

    renderSquare();
}

function renderSquare() {
    gl.clear(gl.COLOR_BUFFER_BIT);

    theta += angularVelocity * direction;
    if (theta > 2 * Math.PI) theta -= (2 * Math.PI);
    if (theta < 0) theta += (2 * Math.PI);

    gl.uniform1f(thetaLoc, theta);

    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);

    window.requestAnimFrame(renderSquare);
}

function updateAngularVelocity(value) {
    angularVelocity = parseFloat(value);
}

function changeDirection() {
    direction *= -1;
}

function slowDown() {
    angularVelocity /= 2;
}

function normalSpeed() {
    angularVelocity = 0.2;
}