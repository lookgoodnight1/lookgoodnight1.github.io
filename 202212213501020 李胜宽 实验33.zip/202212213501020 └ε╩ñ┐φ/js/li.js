"use strict";

var canvas;
var gl;
var program;
var bufferId;
var vPosition;
var theta = 0.0;
var thetaLoc;

function initSquare() {
    canvas = document.getElementById("square-canvas");
    gl = canvas.getContext("webgl2");
    if (!gl) {
        alert("WebGL isn't available");
    }

    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0);

    program = initShaders(gl, "square-v-shader", "square-f-shader");
    gl.useProgram(program);

    var vertices = new Float32Array([
         -0.5, 1, 0,
        -1, 0.5, 0,
        0, 0.5, 0,
        -0.5, 0, 0
    ]);

    bufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

    vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    thetaLoc = gl.getUniformLocation(program, "theta");
	renderSquare();
}

function renderSquare() {
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(thetaLoc, theta);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
}

function showRotation() {
    // 将正方形移动到屏幕中心（假设屏幕中心坐标为(0, 0)）
    var newVertices = new Float32Array([
         0, 0.5, 0,
        -0.5, 0, 0,
        0.5, 0, 0,
        0, -0.5, 0
    ]);
    gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
    gl.bufferData(gl.ARRAY_BUFFER, newVertices, gl.STATIC_DRAW);

    // 进行一周的旋转
    var intervalId = setInterval(function () {
        theta += 0.1;
        if (theta > 2 * Math.PI) {
            theta = 0;
            clearInterval(intervalId);
        }
        renderSquare();
    }, 100);
}