"use strict";

    var canvas;
    var gl;
    var translationX = 0;
    var translationY = 0;
    var scaleX = 1;
    var scaleY = 1;
    var rotationAngle = 0;
    var shearX = 0;
    var shearY = 0;
    var program;
    var animationId;

    function initTriangles() {
        canvas = document.getElementById("triangle-canvas");
        gl = canvas.getContext("webgl2");
        if (!gl) {
            alert("WebGL isn't available");
        }

        gl.viewport(0, 0, canvas.width, canvas.height);
        gl.clearColor(1.0, 1.0, 1.0, 1.0);

        program = initShaders(gl, "trans-v-shader", "trans-f-shader");
        gl.useProgram(program);

        var vertices = new Float32Array([
            0, 1, 0,
            -1, 0, 0,
            1, 0, 0,
            0, -1, 0
        ]);

        var bufferId = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
        gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

        var vPosition = gl.getAttribLocation(program, "vPosition");
        gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(vPosition);

        var translationLoc = gl.getUniformLocation(program, "translation");
        var scaleLoc = gl.getUniformLocation(program, "scale");
        var angleLoc = gl.getUniformLocation(program, "angle");
        var CLoc = gl.getUniformLocation(program, "C");
        var BLoc = gl.getUniformLocation(program, "B");

        gl.uniform2f(translationLoc, translationX, translationY);
        gl.uniform2f(scaleLoc, scaleX, scaleY);
        gl.uniform1f(angleLoc, rotationAngle);
        gl.uniform1f(CLoc, shearX);
        gl.uniform1f(BLoc, shearY);

        renderTriangles();
    }

    function renderTriangles() {
        gl.clear(gl.COLOR_BUFFER_BIT);

        gl.drawArrays(gl.TRIANGLES, 0, 4);
    }

    function startTranslationAnimation() {
        var startTime = performance.now();
        function animate(time) {
            var elapsedTime = time - startTime;
            translationX = Math.sin(elapsedTime * 0.001) * 0.3;
            translationY = Math.cos(elapsedTime * 0.001) * 0.3;
            var translationLoc = gl.getUniformLocation(program, "translation");
            gl.uniform2f(translationLoc, translationX, translationY);
            renderTriangles();
            animationId = requestAnimationFrame(animate);
        }
        animate(startTime);
    }

    function scaleTriangles() {
        scaleX *= 0.5;
        scaleY *= 0.5;
        var scaleLoc = gl.getUniformLocation(program, "scale");
        gl.uniform2f(scaleLoc, scaleX, scaleY);
        renderTriangles();
    }

    function rotateTriangles() {
        rotationAngle += 45;
        var angleLoc = gl.getUniformLocation(program, "angle");
        gl.uniform1f(angleLoc, rotationAngle);
        renderTriangles();
    }

    function stopAnimation() {
        cancelAnimationFrame(animationId);
    }